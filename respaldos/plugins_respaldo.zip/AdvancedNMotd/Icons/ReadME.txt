An attempt will be made to take a random file from this folder and set it as an icon for your motd.
Make sure that only 64x64 images are present in the folder.