File names correspond to the plugin commands.
help.yml - includes everything displayed when you type /anm help command
reload.yml - includes everything displayed when you type /anm help command
unknownCommand.yml - intercept the unknown command